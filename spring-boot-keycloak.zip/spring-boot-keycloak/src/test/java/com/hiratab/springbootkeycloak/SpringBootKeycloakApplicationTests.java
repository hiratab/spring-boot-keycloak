package com.hiratab.springbootkeycloak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootKeycloakApplicationTests {

	@Test
	void contextLoads() {
	}

}
